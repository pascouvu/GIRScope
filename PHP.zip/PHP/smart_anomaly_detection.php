<?php
/**
 * Smart Anomaly Detection - Handles Missing Data Intelligently
 * Adapts analysis based on available data quality
 */

// Load shared library and configuration
require_once('anomaly_lib.php');
$config = require_once('anomaly_config.php');

/**
 * Smart anomaly detection that adapts to data availability
 */
function smartDetectAnomalies($transactions, $config) {
    $anomalies = [];
    $processedVehicles = [];
    $dataQualityStats = [
        'total_transactions' => count($transactions),
        'with_distance' => 0,
        'with_kcons' => 0,
        'analysis_types_used' => []
    ];
    
    logMessage("🧠 Starting smart anomaly detection...");
    logMessage("📊 Analyzing " . count($transactions) . " transactions");
    
    // First pass: assess data quality
    foreach ($transactions as $transaction) {
        if (!empty($transaction['kdelta']) && $transaction['kdelta'] > 0) {
            $dataQualityStats['with_distance']++;
        }
        if (!empty($transaction['kcons'])) {
            $dataQualityStats['with_kcons']++;
        }
    }
    
    $distancePercent = ($dataQualityStats['with_distance'] / $dataQualityStats['total_transactions']) * 100;
    $kconsPercent = ($dataQualityStats['with_kcons'] / $dataQualityStats['total_transactions']) * 100;
    
    logMessage("📈 Data Quality Assessment:");
    logMessage("   - Distance data available: " . round($distancePercent, 1) . "%");
    logMessage("   - Consumption data available: " . round($kconsPercent, 1) . "%");
    
    // Determine which analyses to run based on data quality
    $runConsumptionAnalysis = $kconsPercent > 10; // At least 10% have kcons
    $runVolumeAnalysis = true; // Always run volume analysis
    $runFrequencyAnalysis = $distancePercent < 50; // Only if distance data is poor (likely stationary equipment)
    
    logMessage("🎯 Analysis Strategy:");
    logMessage("   - Consumption analysis: " . ($runConsumptionAnalysis ? "ENABLED" : "DISABLED (insufficient kcons data)"));
    logMessage("   - Volume analysis: " . ($runVolumeAnalysis ? "ENABLED" : "DISABLED"));
    logMessage("   - Frequency analysis: " . ($runFrequencyAnalysis ? "ENABLED (stationary equipment mode)" : "DISABLED (mobile equipment mode)"));
    
    // Second pass: run appropriate analyses
    foreach ($transactions as $transaction) {
        $vehicleId = $transaction['vehicle_id'];
        $vehicleName = $transaction['vehicle_name'];
        
        if (empty($vehicleId)) {
            continue;
        }
        
        // Get baseline data (cached)
        if (!isset($processedVehicles[$vehicleId])) {
            $processedVehicles[$vehicleId] = getBaselineData($config, $vehicleId);
        }
        
        $baselineData = $processedVehicles[$vehicleId];
        $detectedAnomalies = [];
        
        // 1. Consumption analysis (only if data quality is good)
        if ($runConsumptionAnalysis && !empty($transaction['kcons'])) {
            $consumptionResult = analyzeConsumptionAnomaly($transaction, $baselineData);
            if ($consumptionResult['isAnomaly']) {
                $consumptionResult['type'] = 'consumption';
                $detectedAnomalies[] = $consumptionResult;
                $dataQualityStats['analysis_types_used']['consumption'] = true;
                logMessage("🚨 Consumption anomaly: Vehicle $vehicleName - " . $consumptionResult['description']);
            }
        }
        
        // 2. Volume analysis (always run, but with adjusted thresholds for stationary equipment)
        if ($runVolumeAnalysis) {
            $volumeResult = analyzeSmartVolumeAnomaly($transaction, $baselineData, $distancePercent < 50);
            if ($volumeResult['isAnomaly']) {
                $detectedAnomalies[] = $volumeResult;
                $dataQualityStats['analysis_types_used']['volume'] = true;
                logMessage("🚨 Volume anomaly: Vehicle $vehicleName - " . $volumeResult['description']);
            }
        }
        
        // 3. Frequency analysis (adjusted for equipment type)
        if ($runFrequencyAnalysis) {
            $frequencyResult = analyzeSmartFrequencyAnomaly($transaction, $baselineData, $baselineData, $distancePercent < 50);
            if ($frequencyResult['isAnomaly']) {
                $detectedAnomalies[] = $frequencyResult;
                $dataQualityStats['analysis_types_used']['frequency'] = true;
                logMessage("🚨 Frequency anomaly: Vehicle $vehicleName - " . $frequencyResult['description']);
            }
        }
        
        // Add to anomalies if any were detected
        if (!empty($detectedAnomalies)) {
            $transaction['anomaly_analysis'] = $detectedAnomalies;
            $transaction['data_quality_context'] = [
                'has_distance' => !empty($transaction['kdelta']) && $transaction['kdelta'] > 0,
                'has_kcons' => !empty($transaction['kcons']),
                'equipment_type' => $distancePercent < 50 ? 'stationary' : 'mobile'
            ];
            $anomalies[] = $transaction;
        }
    }
    
    logMessage("📊 Smart Detection Summary:");
    logMessage("   - Total anomalies found: " . count($anomalies));
    logMessage("   - Analysis types used: " . implode(', ', array_keys($dataQualityStats['analysis_types_used'])));
    
    return $anomalies;
}

/**
 * Smart volume analysis with adjusted thresholds for stationary equipment
 */
function analyzeSmartVolumeAnomaly($transaction, $baselineTransactions, $isStationaryEquipment) {
    // Use higher threshold for stationary equipment (more variable refueling patterns)
    $standardDeviationThreshold = $isStationaryEquipment ? 2.5 : 2.0;
    $minimumHistoricalSamples = 5;
    
    $baselineVolumes = array_column($baselineTransactions, 'volume');
    
    if (count($baselineVolumes) < $minimumHistoricalSamples) {
        return [
            'isAnomaly' => false,
            'reason' => 'Insufficient samples for volume analysis (' . count($baselineVolumes) . ' < ' . $minimumHistoricalSamples . ')',
            'details' => null
        ];
    }
    
    $stats = calculateStatistics($baselineVolumes);
    if (!$stats) {
        return [
            'isAnomaly' => false,
            'reason' => 'Unable to calculate volume statistics',
            'details' => null
        ];
    }
    
    $currentVolume = $transaction['volume'];
    $zScore = ($currentVolume - $stats['mean']) / $stats['standardDeviation'];
    $isAnomaly = abs($zScore) > $standardDeviationThreshold;
    
    // Determine severity
    $severity = 'low';
    $absZScore = abs($zScore);
    if ($absZScore >= 3.0) {
        $severity = 'critical';
    } elseif ($absZScore >= 2.5) {
        $severity = 'high';
    } elseif ($absZScore >= 2.0) {
        $severity = 'medium';
    }
    
    // Generate description
    $expectedVolume = $stats['mean'];
    $difference = $currentVolume - $expectedVolume;
    $percentageDiff = ($difference / $expectedVolume) * 100;
    $equipmentType = $isStationaryEquipment ? 'stationary equipment' : 'vehicle';
    
    if ($zScore > 0) {
        $description = sprintf(
            "High fuel volume for %s: %.1fL vs expected %.1fL (%.1f%% higher than average)",
            $equipmentType,
            $currentVolume,
            $expectedVolume,
            abs($percentageDiff)
        );
    } else {
        $description = sprintf(
            "Low fuel volume for %s: %.1fL vs expected %.1fL (%.1f%% lower than average)",
            $equipmentType,
            $currentVolume,
            $expectedVolume,
            abs($percentageDiff)
        );
    }
    
    return [
        'isAnomaly' => $isAnomaly,
        'severity' => $severity,
        'type' => 'volume',
        'currentVolume' => $currentVolume,
        'expectedVolume' => $stats['mean'],
        'zScore' => $zScore,
        'baselineSamples' => count($baselineVolumes),
        'description' => $description,
        'threshold_used' => $standardDeviationThreshold,
        'equipment_type' => $equipmentType,
        'details' => $stats
    ];
}

/**
 * Smart frequency analysis with adjusted thresholds for equipment type
 */
function analyzeSmartFrequencyAnomaly($transaction, $baselineTransactions, $allVehicleHistory, $isStationaryEquipment) {
    // Use much higher threshold for stationary equipment (can go months without use)
    $standardDeviationThreshold = $isStationaryEquipment ? 3.0 : 2.0;
    $minimumHistoricalSamples = 2;
    
    if (empty($baselineTransactions)) {
        return [
            'isAnomaly' => false,
            'reason' => 'No baseline transactions available for frequency analysis',
            'details' => null
        ];
    }
    
    // Calculate intervals between baseline transactions
    usort($baselineTransactions, function($a, $b) {
        return strtotime($a['date']) - strtotime($b['date']);
    });
    
    $intervals = [];
    for ($i = 1; $i < count($baselineTransactions); $i++) {
        $daysBetween = (strtotime($baselineTransactions[$i]['date']) - strtotime($baselineTransactions[$i-1]['date'])) / (24 * 3600);
        if ($daysBetween > 0) {
            $intervals[] = $daysBetween;
        }
    }
    
    if (count($intervals) < $minimumHistoricalSamples) {
        return [
            'isAnomaly' => false,
            'reason' => 'Insufficient interval data for frequency analysis (' . count($intervals) . ' < ' . $minimumHistoricalSamples . ')',
            'details' => null
        ];
    }
    
    $stats = calculateStatistics($intervals);
    if (!$stats) {
        return [
            'isAnomaly' => false,
            'reason' => 'Unable to calculate frequency statistics',
            'details' => null
        ];
    }
    
    // Find most recent previous transaction
    $previousTransactions = [];
    foreach ($allVehicleHistory as $t) {
        if (strtotime($t['date']) < strtotime($transaction['date'])) {
            $previousTransactions[] = $t;
        }
    }
    
    if (empty($previousTransactions)) {
        return [
            'isAnomaly' => false,
            'reason' => 'No previous transactions found for frequency comparison',
            'details' => null
        ];
    }
    
    usort($previousTransactions, function($a, $b) {
        return strtotime($b['date']) - strtotime($a['date']);
    });
    
    $daysSinceLastFueling = (strtotime($transaction['date']) - strtotime($previousTransactions[0]['date'])) / (24 * 3600);
    
    // For stationary equipment, ignore frequency anomalies under 60 days
    if ($isStationaryEquipment && $daysSinceLastFueling < 60) {
        return [
            'isAnomaly' => false,
            'reason' => 'Stationary equipment - frequency within normal range (' . round($daysSinceLastFueling, 1) . ' days)',
            'details' => null
        ];
    }
    
    // Same-day refueling check
    if ($daysSinceLastFueling == 0.0) {
        return [
            'isAnomaly' => false,
            'reason' => 'Same-day refueling - not considered an anomaly',
            'details' => null
        ];
    }
    
    $zScore = ($daysSinceLastFueling - $stats['mean']) / $stats['standardDeviation'];
    $isAnomaly = abs($zScore) > $standardDeviationThreshold;
    
    // Determine severity
    $severity = 'low';
    $absZScore = abs($zScore);
    if ($absZScore >= 3.0) {
        $severity = 'critical';
    } elseif ($absZScore >= 2.5) {
        $severity = 'high';
    } elseif ($absZScore >= 2.0) {
        $severity = 'medium';
    }
    
    $equipmentType = $isStationaryEquipment ? 'stationary equipment' : 'vehicle';
    $expectedFrequency = $stats['mean'];
    
    if ($zScore > 0) {
        $description = sprintf(
            "Infrequent refueling for %s: %.1f days since last fueling vs expected %.1f days",
            $equipmentType,
            $daysSinceLastFueling,
            $expectedFrequency
        );
    } else {
        $description = sprintf(
            "Frequent refueling for %s: %.1f days since last fueling vs expected %.1f days",
            $equipmentType,
            $daysSinceLastFueling,
            $expectedFrequency
        );
    }
    
    return [
        'isAnomaly' => $isAnomaly,
        'severity' => $severity,
        'type' => 'frequency',
        'daysSinceLastFueling' => $daysSinceLastFueling,
        'expectedFrequency' => $stats['mean'],
        'zScore' => $zScore,
        'baselineSamples' => count($intervals),
        'description' => $description,
        'threshold_used' => $standardDeviationThreshold,
        'equipment_type' => $equipmentType,
        'details' => $stats
    ];
}

/**
 * Main execution for smart anomaly detection
 */
function main() {
    global $config;
    
    $hours = 72; // 3 days
    $periodLabel = "3-Day Smart";
    
    logMessage("🚀 Starting GIRScope Smart Anomaly Detection...");
    logMessage("📅 Period: $periodLabel ($hours hours)");
    logMessage("");
    
    try {
        // Get transactions
        $transactions = getFuelTransactions($config, $hours);
        logMessage("Found " . count($transactions) . " transactions");
        
        if (empty($transactions)) {
            logMessage("⚠️ No transactions found for analysis period");
            return;
        }
        
        // Run smart anomaly detection
        $anomalies = smartDetectAnomalies($transactions, $config);
        
        // Update database
        $updatedCount = updateAnomalyFlagsInSupabase($anomalies, $config);
        
        // Generate and send emails
        $emailsSent = sendAnomalyEmails($anomalies, $periodLabel, $hours, $config);
        
        // Final summary
        logMessage("");
        logMessage("📊 Smart Analysis Summary:");
        logMessage("   - Transactions analyzed: " . count($transactions));
        logMessage("   - Anomalies detected: " . count($anomalies));
        logMessage("   - Database records updated: $updatedCount");
        logMessage("   - Emails sent: $emailsSent");
        logMessage("✅ Smart anomaly detection completed successfully!");
        
    } catch (Exception $e) {
        logMessage("❌ Error: " . $e->getMessage());
        exit(1);
    }
}

// Run if called directly
if (basename(__FILE__) == basename($_SERVER['SCRIPT_NAME'])) {
    main();
}
?>