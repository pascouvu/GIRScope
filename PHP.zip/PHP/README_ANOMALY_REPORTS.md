# GIRScope Daily Anomaly Reports

This system automatically checks for fuel consumption anomalies daily and sends email notifications to specified recipients.

## 📁 Files Overview

All files are located in the `PHP/` folder:

- **`PHP/daily_anomaly_report.php`** - Main script that runs daily
- **`PHP/anomaly_config.php`** - Configuration file for settings and recipients
- **`PHP/setup_anomaly_reports.sh`** - Setup script for initial configuration
- **`PHP/README_ANOMALY_REPORTS.md`** - This documentation file
- **`PHP/PRIVACY_POLICY.md`** - Privacy policy template
- **`PHP/TERMS_AND_CONDITIONS.md`** - Terms and conditions template

## 🚀 Quick Setup

1. **Run the setup script:**
   ```bash
   chmod +x setup_anomaly_reports.sh
   ./setup_anomaly_reports.sh
   ```

2. **Set environment variables:**
   ```bash
   export SMTP_USER='your-smtp-username'
   export SMTP_PASSWORD='your-smtp-password'
   ```

3. **Update configuration:**
   Edit `anomaly_config.php` to add your email recipients

4. **Test the script:**
   ```bash
   php PHP/daily_anomaly_report.php
   ```

5. **Set up cron job:**
   ```bash
   crontab -e
   # Add this line for daily 8 AM execution:
   0 8 * * * /usr/bin/php /path/to/PHP/daily_anomaly_report.php >> /var/log/girscope_anomaly_reports.log 2>&1
   ```

## ⚙️ Configuration

### Email Recipients

Edit `anomaly_config.php` to add/modify recipients:

```php
'recipients' => [
    [
        'email' => 'admin@company.com',
        'name' => 'Fleet Administrator'
    ],
    [
        'email' => 'manager@company.com',
        'name' => 'Fleet Manager'
    ],
    // Add more recipients...
],
```

### SMTP Settings

The script uses the existing SMTP configuration:
- **Host:** mail.iec.vu
- **Port:** 465
- **Security:** SSL
- **Authentication:** Required (via environment variables)

### Report Settings

You can customize:
- **Report hours:** How many hours back to check (default: 24)
- **Minimum severity:** Minimum anomaly severity to include
- **Company information:** Name, logo, support contacts

## 📧 Email Features

The generated emails include:

### 📊 Summary Section
- Total anomalies found
- Time period covered
- Breakdown by severity level

### 🔍 Detailed Reports
- Vehicle information
- Driver details
- Location and time
- Fuel volume
- Specific anomaly descriptions
- Severity indicators with emojis

### 🎨 Professional Styling
- HTML formatted emails
- Color-coded severity levels
- Responsive design
- Company branding

## 🕐 Cron Job Examples

### Daily at 8:00 AM
```bash
0 8 * * * /usr/bin/php /path/to/PHP/daily_anomaly_report.php >> /var/log/girscope_anomaly_reports.log 2>&1
```

### Twice daily (8 AM and 6 PM)
```bash
0 8,18 * * * /usr/bin/php /path/to/PHP/daily_anomaly_report.php >> /var/log/girscope_anomaly_reports.log 2>&1
```

### Weekdays only at 9 AM
```bash
0 9 * * 1-5 /usr/bin/php /path/to/PHP/daily_anomaly_report.php >> /var/log/girscope_anomaly_reports.log 2>&1
```

## 🔧 Troubleshooting

### Common Issues

1. **SMTP Authentication Failed**
   - Check environment variables: `echo $SMTP_USER`
   - Verify credentials with your email provider

2. **Database Connection Failed**
   - Verify Supabase URL and API key in config
   - Check network connectivity

3. **No Anomalies Found**
   - This is normal if no anomalies occurred
   - Check the database directly to verify data

4. **PHP Errors**
   - Check PHP error logs: `tail -f /var/log/php_errors.log`
   - Verify all required PHP extensions are installed

### Testing Commands

```bash
# Test PHP syntax
php -l daily_anomaly_report.php

# Test configuration loading
php -r "var_dump(require 'anomaly_config.php');"

# Run script manually with verbose output
php daily_anomaly_report.php

# Check cron job logs
tail -f /var/log/girscope_anomaly_reports.log
```

## 📝 Logging

The script logs all activities with timestamps:
- Anomaly detection results
- Email sending status
- Error messages
- Execution summary

Logs are written to: `/var/log/girscope_anomaly_reports.log`

## 🔒 Security Notes

- Store SMTP credentials as environment variables, not in files
- Restrict file permissions: `chmod 644 anomaly_config.php`
- Use HTTPS/SSL for all email communications
- Regularly rotate SMTP passwords
- Monitor log files for suspicious activity

## 📞 Support

For issues or questions:
- Check the log files first
- Verify configuration settings
- Test database connectivity
- Contact: IEC (IT Engineers Company) - https://iec.vu

## 🔄 Updates

To update the system:
1. Backup current configuration
2. Update script files
3. Test manually before updating cron job
4. Monitor first few automated runs

---

**Last Updated:** January 2025  
**Version:** 1.0.0