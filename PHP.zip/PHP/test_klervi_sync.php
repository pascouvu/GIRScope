<?php
/**
 * Test Klervi API Sync with proper last_id handling
 */

// Load configuration
$config = require_once('anomaly_config.php');
require_once('anomaly_lib.php');

echo "<h2>Testing Klervi API Sync with last_id</h2>";

// Step 1: Get the most recent transaction from Supabase (like Dart app)
echo "<h3>Step 1: Getting last transaction ID from Supabase</h3>";
try {
    $lastTxUrl = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
                'select=id,date&order=date.desc&limit=1';
    $lastTxResponse = makeSupabaseRequest($lastTxUrl, $config);
    
    $lastId = null;
    if (!empty($lastTxResponse) && isset($lastTxResponse[0]['id'])) {
        $lastId = $lastTxResponse[0]['id'];
        $lastDate = $lastTxResponse[0]['date'];
        echo "<p>✅ Found last transaction ID: <strong>$lastId</strong></p>";
        echo "<p>Last transaction date: <strong>$lastDate</strong></p>";
    } else {
        echo "<p>⚠️ No transactions found in Supabase</p>";
    }
} catch (Exception $e) {
    echo "<p>❌ Error getting last transaction: " . $e->getMessage() . "</p>";
}

// Step 2: Call Klervi API with last_id parameter
echo "<h3>Step 2: Calling Klervi API with last_id</h3>";

$w150ApiUrl = $config['w150_api_url'];
$w150ApiKey = $config['w150_api_key'];

// Build URL with lastId parameter (exactly like Dart)
$queryParams = [];
if ($lastId) {
    $queryParams['last_id'] = $lastId;
}
$w150UrlWithParams = $w150ApiUrl;
if (!empty($queryParams)) {
    $w150UrlWithParams .= '?' . http_build_query($queryParams);
}

echo "<p>Calling: <strong>$w150UrlWithParams</strong></p>";

// Make request to Klervi API
$headers = [
    'X-Klervi-API-Key: ' . $w150ApiKey,
    'Content-Type: application/json'
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $w150UrlWithParams);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$w150Response = curl_exec($ch);
$w150HttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$w150Error = curl_error($ch);
curl_close($ch);

if ($w150Error) {
    echo "<p>❌ cURL Error: $w150Error</p>";
    exit;
}

if ($w150HttpCode !== 200) {
    echo "<p>❌ HTTP Error: $w150HttpCode</p>";
    echo "<p>Response: " . substr($w150Response, 0, 500) . "</p>";
    exit;
}

$w150Data = json_decode($w150Response, true);
if (!$w150Data) {
    echo "<p>❌ Invalid JSON response</p>";
    exit;
}

// Step 3: Analyze the response
echo "<h3>Step 3: Analyzing API Response</h3>";

echo "<p><strong>Response structure:</strong></p>";
echo "<pre>" . json_encode(array_keys($w150Data), JSON_PRETTY_PRINT) . "</pre>";

// Handle different response formats (exactly like Dart implementation)
$w150Transactions = [];
$moreData = false;

if (is_array($w150Data) && isset($w150Data['result'])) {
    $w150Transactions = $w150Data['result'];
    $moreData = $w150Data['more'] ?? false;
} elseif (is_array($w150Data) && isset($w150Data['data'])) {
    $w150Transactions = $w150Data['data'];
    $moreData = $w150Data['more'] ?? false;
} elseif (is_array($w150Data) && isset($w150Data['transactions'])) {
    $w150Transactions = $w150Data['transactions'];
    $moreData = $w150Data['more'] ?? false;
} elseif (is_array($w150Data) && isset($w150Data['results'])) {
    $w150Transactions = $w150Data['results'];
    $moreData = $w150Data['more'] ?? false;
} elseif (is_array($w150Data)) {
    $w150Transactions = $w150Data;
    $moreData = false; // If it's a direct array, assume no pagination
}

echo "<p><strong>Found transactions:</strong> " . count($w150Transactions) . "</p>";
echo "<p><strong>More data available:</strong> " . ($moreData ? 'Yes' : 'No') . "</p>";

if (!empty($w150Transactions)) {
    echo "<h4>First transaction structure:</h4>";
    $firstTransaction = $w150Transactions[0];
    echo "<pre>" . json_encode($firstTransaction, JSON_PRETTY_PRINT) . "</pre>";
    
    echo "<h4>Transaction dates (first 5):</h4>";
    for ($i = 0; $i < min(5, count($w150Transactions)); $i++) {
        $tx = $w150Transactions[$i];
        $id = $tx['id'] ?? 'no-id';
        $date = $tx['date'] ?? 'no-date';
        echo "<p>$i: ID=$id, Date=$date</p>";
    }
}

echo "<p><a href='web_anomaly_report.php'>← Back to Anomaly Report</a></p>";
?>