<?php
/**
 * Database synchronization script for GIRScope
 * Syncs data from the main fuel management system to Supabase
 */

// Load configuration
$config = require_once('anomaly_config.php');

function logMessage($message) {
    echo "[" . date('Y-m-d H:i:s') . "] " . $message . "\n";
}

function makeSupabaseRequest($url, $config, $method = 'GET', $data = null) {
    $headers = [
        'apikey: ' . $config['supabase_key'],
        'Authorization: Bearer ' . $config['supabase_key'],
        'Content-Type: application/json'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
    } elseif ($method === 'PATCH') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode < 200 || $httpCode >= 300) {
        throw new Exception("Supabase request failed with HTTP code: $httpCode. Response: $response");
    }
    
    return json_decode($response, true);
}

/**
 * Sync departments from main system to Supabase
 */
function syncDepartments($config) {
    logMessage("Syncing departments...");
    
    // This would typically connect to your main fuel management system
    // For now, we'll just check what's in Supabase
    $url = $config['supabase_url'] . '/rest/v1/departments?select=*&limit=100';
    $departments = makeSupabaseRequest($url, $config);
    
    logMessage("Found " . count($departments) . " departments in Supabase");
    return count($departments);
}

/**
 * Sync sites from main system to Supabase
 */
function syncSites($config) {
    logMessage("Syncing sites...");
    
    $url = $config['supabase_url'] . '/rest/v1/sites?select=*&limit=100';
    $sites = makeSupabaseRequest($url, $config);
    
    logMessage("Found " . count($sites) . " sites in Supabase");
    return count($sites);
}

/**
 * Sync vehicles from main system to Supabase
 */
function syncVehicles($config) {
    logMessage("Syncing vehicles...");
    
    $url = $config['supabase_url'] . '/rest/v1/vehicles?select=*&limit=1000';
    $vehicles = makeSupabaseRequest($url, $config);
    
    logMessage("Found " . count($vehicles) . " vehicles in Supabase");
    return count($vehicles);
}

/**
 * Sync drivers from main system to Supabase
 */
function syncDrivers($config) {
    logMessage("Syncing drivers...");
    
    $url = $config['supabase_url'] . '/rest/v1/drivers?select=*&limit=1000';
    $drivers = makeSupabaseRequest($url, $config);
    
    logMessage("Found " . count($drivers) . " drivers in Supabase");
    return count($drivers);
}

/**
 * Sync fuel transactions from main system to Supabase
 */
function syncFuelTransactions($config) {
    logMessage("Syncing fuel transactions...");
    
    // Get recent transactions (last 30 days)
    $thirtyDaysAgo = date('Y-m-d\TH:i:s', strtotime('-30 days'));
    $url = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
           'select=*&' .
           'date=gte.' . urlencode($thirtyDaysAgo) . '&' .
           'order=date.desc&' .
           'limit=5000';
    
    $transactions = makeSupabaseRequest($url, $config);
    
    logMessage("Found " . count($transactions) . " fuel transactions in last 30 days");
    return count($transactions);
}

/**
 * Run anomaly detection on recent transactions
 */
function runAnomalyDetection($config) {
    logMessage("Running anomaly detection...");
    
    // Include the anomaly detection functions from the main script
    require_once('daily_anomaly_report.php');
    
    // Get transactions from last 7 days
    $transactions = getFuelTransactions($config, 168); // 7 days
    logMessage("Analyzing " . count($transactions) . " transactions for anomalies");
    
    $anomalies = detectAnomalies($transactions, $config);
    logMessage("Detected " . count($anomalies) . " anomalies");
    
    // Update has_anomalies flag in database
    $updatedCount = 0;
    foreach ($anomalies as $anomaly) {
        try {
            $updateUrl = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
                        'id=eq.' . urlencode($anomaly['id']);
            
            $updateData = ['has_anomalies' => true];
            makeSupabaseRequest($updateUrl, $config, 'PATCH', $updateData);
            $updatedCount++;
        } catch (Exception $e) {
            logMessage("Failed to update transaction {$anomaly['id']}: " . $e->getMessage());
        }
    }
    
    logMessage("Updated $updatedCount transactions with anomaly flags");
    return count($anomalies);
}

/**
 * Main sync execution
 */
function main() {
    global $config;
    
    logMessage("Starting GIRScope database synchronization...");
    
    $syncResults = [];
    
    try {
        // Sync all data types
        $syncResults['departments'] = syncDepartments($config);
        $syncResults['sites'] = syncSites($config);
        $syncResults['vehicles'] = syncVehicles($config);
        $syncResults['drivers'] = syncDrivers($config);
        $syncResults['fuel_transactions'] = syncFuelTransactions($config);
        
        // Run anomaly detection
        $syncResults['anomalies_detected'] = runAnomalyDetection($config);
        
        logMessage("Synchronization completed successfully!");
        logMessage("Summary:");
        foreach ($syncResults as $type => $count) {
            logMessage("  - " . ucfirst(str_replace('_', ' ', $type)) . ": $count");
        }
        
    } catch (Exception $e) {
        logMessage("❌ Synchronization failed: " . $e->getMessage());
        exit(1);
    }
}

// Run the sync if this script is called directly
if (basename(__FILE__) == basename($_SERVER['SCRIPT_NAME'])) {
    main();
}
?>