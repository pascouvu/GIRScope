<?php
/**
 * Web-based Data Quality Analysis
 * Analyzes fuel transaction data quality via web interface
 */

// Set content type for web output
header('Content-Type: text/html; charset=UTF-8');

// Override logMessage for web output
function logMessage($message) {
    $color = '#059669';
    if (strpos($message, '⚠️') !== false || strpos($message, 'WARNING') !== false) {
        $color = '#ea580c';
    } elseif (strpos($message, '❌') !== false || strpos($message, 'CRITICAL') !== false) {
        $color = '#dc2626';
    } elseif (strpos($message, '💡') !== false || strpos($message, 'INFO') !== false) {
        $color = '#2563eb';
    }
    
    echo "<div style='color: $color; margin: 5px 0; font-family: monospace;'>" . htmlspecialchars($message) . "</div>";
    flush();
}

// Load the analysis script
require_once('analyze_data_quality.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>GIRScope Data Quality Analysis</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1000px; margin: 20px auto; padding: 20px; }
        .header { background: #2563eb; color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 30px; }
        .output { background: #f8fafc; padding: 20px; border-radius: 8px; margin-top: 20px; }
        .back-button { background: #6b7280; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; display: inline-block; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>📊 GIRScope Data Quality Analysis</h1>
        <p>Understanding why anomalies are being detected</p>
    </div>
    
    <div class="output">
        <?php
        // The analysis runs automatically when the file is included
        ?>
    </div>
    
    <div style="text-align: center;">
        <a href="web_anomaly_report.php" class="back-button">← Back to Anomaly Reports</a>
    </div>
</body>
</html>