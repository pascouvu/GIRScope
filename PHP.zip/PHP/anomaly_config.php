<?php
/**
 * Configuration file for Daily Anomaly Report
 * Modify this file to customize settings
 */

return [
    // Database Configuration
    'supabase_url' => 'https://doihhqeaftqibqynaujn.supabase.co',
    'supabase_key' => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRvaWhocWVhZnRxaWJxeW5hdWpuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM3NTgzMTAsImV4cCI6MjA2OTMzNDMxMH0.Z6iPcCt8p0n-13q7PWr4Vn58Tf9trEftS89p3xM8kwU',
    
    // W150 API Configuration (Klervi API)
    'w150_api_url' => 'https://pierre-brunet-entreprise-vu-gir.klervi.net/api-impexp/transac_fuels',
    'w150_api_key' => 'c08951d341ca7c8b2d034c8d05ca8537',
    'w150_sync_enabled' => true, // Enable W150 API sync
    
    // Email Configuration
    'smtp_host' => 'mail.iec.vu',
    'smtp_port' => 465,
    'smtp_secure' => 'ssl',
    'default_from' => 'noreply@iec.vu',
    'sender_name' => 'GIRScope Anomaly System',
    
    // Report Configuration
    'report_hours' => 24, // Hours to look back for anomalies
    'min_severity_level' => 'low', // Minimum severity to include (low, medium, high, critical)
    
    // Email Recipients
    'recipients' => [
        [
            'email' => 'pascal@iec.vu',
            'name' => 'Pascal Kiro'
        ],
        // Add more recipients as needed
    ],
    
    // Email Template Settings
    'company_name' => 'Your Company Name',
    'company_logo_url' => '', // Optional: URL to company logo
    'support_email' => 'support@company.com',
    'support_phone' => '+1-234-567-8900',
    
    // Logging
    'log_file' => '/var/log/girscope_anomaly_reports.log',
    'debug_mode' => false,
];
?>