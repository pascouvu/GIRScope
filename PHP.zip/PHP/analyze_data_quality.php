<?php
/**
 * Data Quality Analysis Script
 * Analyzes the quality of fuel transaction data to understand anomaly patterns
 */

// Load shared library and configuration
require_once('anomaly_lib.php');
$config = require_once('anomaly_config.php');

/**
 * Analyze data quality for different time periods
 */
function analyzeDataQuality($config, $hours, $periodLabel) {
    logMessage("🔍 Analyzing data quality for $periodLabel ($hours hours)...");
    
    $transactions = getFuelTransactions($config, $hours);
    
    if (empty($transactions)) {
        logMessage("⚠️ No transactions found for $periodLabel");
        return;
    }
    
    $totalTransactions = count($transactions);
    $withDistance = 0;
    $withoutDistance = 0;
    $withKcons = 0;
    $withoutKcons = 0;
    $zeroDistance = 0;
    $vehicleStats = [];
    
    logMessage("📊 Analyzing $totalTransactions transactions...");
    
    foreach ($transactions as $t) {
        $vehicleName = $t['vehicle_name'];
        
        // Initialize vehicle stats
        if (!isset($vehicleStats[$vehicleName])) {
            $vehicleStats[$vehicleName] = [
                'total' => 0,
                'with_distance' => 0,
                'zero_distance' => 0,
                'with_kcons' => 0,
                'avg_volume' => 0,
                'volumes' => []
            ];
        }
        
        $vehicleStats[$vehicleName]['total']++;
        $vehicleStats[$vehicleName]['volumes'][] = $t['volume'];
        
        // Check distance data
        if (isset($t['kdelta']) && $t['kdelta'] !== null) {
            if ($t['kdelta'] > 0) {
                $withDistance++;
                $vehicleStats[$vehicleName]['with_distance']++;
            } else {
                $zeroDistance++;
                $vehicleStats[$vehicleName]['zero_distance']++;
            }
        } else {
            $withoutDistance++;
        }
        
        // Check kcons data
        if (isset($t['kcons']) && $t['kcons'] !== null && $t['kcons'] > 0) {
            $withKcons++;
            $vehicleStats[$vehicleName]['with_kcons']++;
        } else {
            $withoutKcons++;
        }
    }
    
    // Calculate vehicle averages
    foreach ($vehicleStats as $vehicleName => &$stats) {
        $stats['avg_volume'] = array_sum($stats['volumes']) / count($stats['volumes']);
    }
    
    logMessage("");
    logMessage("📈 $periodLabel Data Quality Summary:");
    logMessage("   Total transactions: $totalTransactions");
    logMessage("   With valid distance (kdelta > 0): $withDistance (" . round(($withDistance/$totalTransactions)*100, 1) . "%)");
    logMessage("   With zero distance (kdelta = 0): $zeroDistance (" . round(($zeroDistance/$totalTransactions)*100, 1) . "%)");
    logMessage("   Without distance data: $withoutDistance (" . round(($withoutDistance/$totalTransactions)*100, 1) . "%)");
    logMessage("   With consumption data (kcons): $withKcons (" . round(($withKcons/$totalTransactions)*100, 1) . "%)");
    logMessage("   Without consumption data: $withoutKcons (" . round(($withoutKcons/$totalTransactions)*100, 1) . "%)");
    
    logMessage("");
    logMessage("🚗 Vehicle-by-Vehicle Analysis:");
    
    // Sort vehicles by total transactions
    uasort($vehicleStats, function($a, $b) {
        return $b['total'] - $a['total'];
    });
    
    foreach ($vehicleStats as $vehicleName => $stats) {
        $distancePercent = round(($stats['with_distance'] / $stats['total']) * 100, 1);
        $kconsPercent = round(($stats['with_kcons'] / $stats['total']) * 100, 1);
        
        logMessage("   $vehicleName:");
        logMessage("      - Total transactions: {$stats['total']}");
        logMessage("      - With distance: {$stats['with_distance']} ({$distancePercent}%)");
        logMessage("      - Zero distance: {$stats['zero_distance']}");
        logMessage("      - With kcons: {$stats['with_kcons']} ({$kconsPercent}%)");
        logMessage("      - Avg volume: " . number_format($stats['avg_volume'], 1) . "L");
        
        // Identify potential issues
        if ($distancePercent < 50) {
            logMessage("      ⚠️ LOW DISTANCE DATA - May cause consumption analysis issues");
        }
        if ($stats['zero_distance'] > 0) {
            logMessage("      ⚠️ HAS ZERO DISTANCE - May be stationary equipment");
        }
        if ($kconsPercent < 50) {
            logMessage("      ⚠️ LOW KCONS DATA - Consumption analysis may not run");
        }
        logMessage("");
    }
    
    return [
        'total' => $totalTransactions,
        'with_distance' => $withDistance,
        'zero_distance' => $zeroDistance,
        'with_kcons' => $withKcons,
        'vehicle_stats' => $vehicleStats
    ];
}

/**
 * Analyze why anomalies are being detected
 */
function analyzeAnomalyReasons($config) {
    logMessage("🔍 Analyzing why anomalies are being detected...");
    
    // Get transactions that Flutter marked as anomalies
    $url = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
           'select=*&' .
           'has_anomalies=eq.true&' .
           'order=date.desc&' .
           'limit=20';
    
    $anomalyTransactions = makeSupabaseRequest($url, $config);
    
    logMessage("Found " . count($anomalyTransactions) . " transactions marked as anomalies by Flutter");
    
    if (empty($anomalyTransactions)) {
        logMessage("⚠️ No existing anomalies found in database");
        return;
    }
    
    $reasonCounts = [
        'no_distance' => 0,
        'zero_distance' => 0,
        'has_distance' => 0,
        'has_kcons' => 0,
        'frequency_likely' => 0
    ];
    
    logMessage("");
    logMessage("🚨 Existing Anomaly Analysis:");
    
    foreach ($anomalyTransactions as $t) {
        $vehicleName = $t['vehicle_name'];
        $date = date('M j, Y H:i', strtotime($t['date']));
        $kdelta = $t['kdelta'] ?? null;
        $kcons = $t['kcons'] ?? null;
        
        logMessage("   $vehicleName ($date):");
        logMessage("      - Volume: {$t['volume']}L");
        logMessage("      - Distance (kdelta): " . ($kdelta ?? 'NULL'));
        logMessage("      - Consumption (kcons): " . ($kcons ?? 'NULL'));
        
        // Analyze why this was marked as anomaly
        if ($kdelta === null) {
            $reasonCounts['no_distance']++;
            logMessage("      - Likely reason: NO DISTANCE DATA");
        } elseif ($kdelta == 0) {
            $reasonCounts['zero_distance']++;
            logMessage("      - Likely reason: ZERO DISTANCE (stationary equipment?)");
        } else {
            $reasonCounts['has_distance']++;
            logMessage("      - Has distance data - likely volume/frequency anomaly");
        }
        
        if ($kcons !== null && $kcons > 0) {
            $reasonCounts['has_kcons']++;
        }
        
        // Check if it's likely a frequency anomaly (long time since last refuel)
        $daysSinceTransaction = (time() - strtotime($t['date'])) / (24 * 3600);
        if ($daysSinceTransaction > 7) {
            $reasonCounts['frequency_likely']++;
            logMessage("      - Likely FREQUENCY anomaly (transaction is " . round($daysSinceTransaction, 1) . " days old)");
        }
        
        logMessage("");
    }
    
    logMessage("📊 Anomaly Reason Summary:");
    logMessage("   No distance data: {$reasonCounts['no_distance']}");
    logMessage("   Zero distance: {$reasonCounts['zero_distance']}");
    logMessage("   Has distance data: {$reasonCounts['has_distance']}");
    logMessage("   Has kcons data: {$reasonCounts['has_kcons']}");
    logMessage("   Likely frequency anomalies: {$reasonCounts['frequency_likely']}");
}

/**
 * Provide recommendations
 */
function provideRecommendations($dataQuality) {
    logMessage("");
    logMessage("💡 RECOMMENDATIONS:");
    logMessage(str_repeat("=", 60));
    
    $totalTransactions = $dataQuality['total'];
    $distancePercent = ($dataQuality['with_distance'] / $totalTransactions) * 100;
    $kconsPercent = ($dataQuality['with_kcons'] / $totalTransactions) * 100;
    
    if ($distancePercent < 30) {
        logMessage("🔧 CRITICAL: Only " . round($distancePercent, 1) . "% of transactions have distance data");
        logMessage("   - Check vehicle odometer/GPS systems");
        logMessage("   - Verify data sync from W150 system");
        logMessage("   - Consider using volume-only analysis for stationary equipment");
    }
    
    if ($dataQuality['zero_distance'] > ($totalTransactions * 0.5)) {
        logMessage("🏭 INFO: Many transactions have zero distance");
        logMessage("   - This suggests stationary equipment (generators, pumps)");
        logMessage("   - Consider separate analysis rules for stationary vs mobile equipment");
        logMessage("   - Volume and frequency analysis may be more relevant than consumption");
    }
    
    if ($kconsPercent < 50) {
        logMessage("📊 WARNING: Only " . round($kconsPercent, 1) . "% of transactions have kcons data");
        logMessage("   - Consumption analysis will be limited");
        logMessage("   - Focus on volume and frequency anomaly detection");
    }
    
    logMessage("");
    logMessage("🎯 SUGGESTED ACTIONS:");
    logMessage("   1. Filter out stationary equipment from consumption analysis");
    logMessage("   2. Use volume-based anomaly detection for equipment without distance");
    logMessage("   3. Implement equipment-type classification (mobile vs stationary)");
    logMessage("   4. Check W150 system configuration for distance data collection");
}

/**
 * Main execution
 */
function main() {
    global $config;
    
    logMessage("🚀 Starting GIRScope Data Quality Analysis...");
    logMessage("");
    
    try {
        // Analyze different time periods
        $periods = [
            ['hours' => 72, 'label' => '3-Day'],
            ['hours' => 168, 'label' => '7-Day']
        ];
        
        $overallQuality = null;
        
        foreach ($periods as $period) {
            $quality = analyzeDataQuality($config, $period['hours'], $period['label']);
            if ($period['hours'] === 168) { // Use 7-day data for recommendations
                $overallQuality = $quality;
            }
            logMessage("");
        }
        
        // Analyze existing anomalies
        analyzeAnomalyReasons($config);
        
        // Provide recommendations
        if ($overallQuality) {
            provideRecommendations($overallQuality);
        }
        
        logMessage("");
        logMessage("✅ Data quality analysis completed!");
        
    } catch (Exception $e) {
        logMessage("❌ Error: " . $e->getMessage());
        exit(1);
    }
}

// Run the analysis
main();
?>