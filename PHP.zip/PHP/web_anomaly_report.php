<?php
/**
 * Web-based Anomaly Report Script
 * Runs anomaly detection and sends emails via web interface
 * 
 * Usage: https://api.iec.vu/girscope/web_anomaly_report.php?period=3days&action=send
 */

// Set content type for web output
header('Content-Type: text/html; charset=UTF-8');

// Override logMessage before loading the library
function logMessage($message) {
    $color = '#059669';
    echo "<div style='color: $color; margin: 5px 0;'>" . htmlspecialchars($message) . "</div>";
    flush();
}

// Load shared library and configuration
require_once('anomaly_lib.php');
$config = require_once('anomaly_config.php');

/**
 * Generate HTML output for web interface
 */
function webOutput($message, $isError = false) {
    $color = $isError ? '#dc2626' : '#059669';
    echo "<div style='color: $color; margin: 5px 0;'>" . htmlspecialchars($message) . "</div>";
    flush();
}

/**
 * Web-specific log function that outputs HTML
 */
function webLogMessage($message) {
    webOutput($message);
}

/**
 * Run anomaly analysis for web interface
 */
function runWebAnomalyAnalysis($period, $action) {
    global $config;
    
    // Determine hours based on period
    switch (strtolower($period)) {
        case '1day':
            $hours = 24;
            $periodLabel = '1-Day';
            break;
        case '3days':
            $hours = 72;
            $periodLabel = '3-Day';
            break;
        case '7days':
            $hours = 168;
            $periodLabel = '7-Day';
            break;
        default:
            webOutput("❌ Invalid period. Use: 1day, 3days, or 7days", true);
            return;
    }
    
    webOutput("🚀 Starting GIRScope $periodLabel anomaly detection...");
    webOutput("");
    
    try {
        // Get transactions
        $transactions = getFuelTransactions($config, $hours);
        webOutput("Found " . count($transactions) . " transactions in last $hours hours");
        
        // Sync latest data from W150 API before analysis (if enabled)
        if ($action === 'send' && $config['w150_sync_enabled']) {
            webOutput("🔄 Syncing latest data from W150 API...");
            $syncResult = syncFromW150API($config);
            if ($syncResult['success']) {
                webOutput("✅ W150 sync completed: " . $syncResult['message']);
                
                // Refresh transactions after sync
                $transactions = getFuelTransactions($config, $hours);
                webOutput("After sync: Found " . count($transactions) . " transactions");
            } else {
                webOutput("⚠️ W150 sync failed: " . $syncResult['message']);
                webOutput("Continuing with existing data...");
            }
        } elseif ($action === 'send') {
            webOutput("ℹ️ W150 sync disabled in configuration");
        }
        
        if (empty($transactions)) {
            webOutput("⚠️ No transactions found for analysis period");
            
            if ($action === 'send') {
                // Still send email to notify about no data
                $emailBody = generateEmailBody([], $periodLabel, $hours);
                $subject = "GIRScope $periodLabel Anomaly Report - " . date('M j, Y') . " (No data)";
                
                $emailsSent = 0;
                foreach ($config['recipients'] as $recipient) {
                    if (sendEmail($recipient['email'], $recipient['name'], $subject, $emailBody, $config)) {
                        $emailsSent++;
                    }
                }
                
                webOutput("✅ No-data notification emails sent to $emailsSent recipients");
            }
            return;
        }
        
        // Detect anomalies
        $analysisResult = detectAnomalies($transactions, $config);
        $anomalies = $analysisResult['anomalies'];
        $vehicleAnalysis = $analysisResult['vehicleAnalysis'];
        
        webOutput("Found " . count($anomalies) . " anomalies");
        webOutput("Analyzed " . count($vehicleAnalysis) . " vehicles");
        
        if ($action === 'send') {
            // Update anomaly flags in Supabase
            $updatedCount = updateAnomalyFlagsInSupabase($anomalies, $config);
            
            // Send email reports
            webOutput("📧 Starting email sending process...");
            webOutput("📧 Number of recipients: " . count($config['recipients']));
            
            // Check SMTP credentials before attempting to send
            $smtpUser = getenv('SMTP_USER');
            $smtpPassword = getenv('SMTP_PASSWORD');
            webOutput("📧 SMTP User: " . ($smtpUser ? "✅ $smtpUser" : "❌ Not set"));
            webOutput("📧 SMTP Password: " . ($smtpPassword ? "✅ Set" : "❌ Not set"));
            
            $emailsSent = sendAnomalyEmails($anomalies, $periodLabel, $hours, $config, $vehicleAnalysis);
            webOutput("📧 Email sending completed. Emails sent: $emailsSent");
            
            // Summary
            webOutput("");
            webOutput("📊 $periodLabel Analysis Summary:");
            webOutput("   - Transactions analyzed: " . count($transactions));
            webOutput("   - Anomalies detected: " . count($anomalies));
            webOutput("   - Database records updated: $updatedCount");
            webOutput("   - Emails sent: $emailsSent");
            webOutput("✅ $periodLabel anomaly detection completed successfully!");
            
        } elseif ($action === 'preview') {
            // Generate preview
            $emailBody = generateEmailBody($anomalies, $periodLabel, $hours);
            $filename = "email_preview_{$periodLabel}_" . date('Y-m-d_H-i-s') . ".html";
            file_put_contents($filename, $emailBody);
            
            webOutput("✅ Email preview saved to: $filename");
            webOutput("");
            webOutput("📧 Email subject would be: GIRScope $periodLabel Anomaly Report - " . date('M j, Y') . 
                      (count($anomalies) > 0 ? " (" . count($anomalies) . " anomalies)" : " (No anomalies)"));
            
            // Show preview link
            $previewUrl = "https://api.iec.vu/girscope/$filename";
            webOutput("");
            webOutput("🔗 <a href='$previewUrl' target='_blank' style='color: #2563eb;'>Click here to view email preview</a>");
        }
        
    } catch (Exception $e) {
        webOutput("❌ Error in $periodLabel analysis: " . $e->getMessage(), true);
    }
}

/**
 * Generate web interface
 */
function generateWebInterface() {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>GIRScope Anomaly Detection</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
            .header { background: #2563eb; color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 30px; }
            .button { background: #2563eb; color: white; padding: 12px 24px; border: none; border-radius: 6px; text-decoration: none; display: inline-block; margin: 5px; cursor: pointer; }
            .button:hover { background: #1d4ed8; }
            .button.preview { background: #059669; }
            .button.preview:hover { background: #047857; }
            .output { background: #f8fafc; padding: 20px; border-radius: 8px; margin-top: 20px; font-family: monospace; }
            .section { margin: 20px 0; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🚨 GIRScope Anomaly Detection</h1>
            <p>Web Interface for Anomaly Analysis and Email Reports</p>
        </div>
        
        <div class="section">
            <h2>📧 Send Anomaly Reports</h2>
            <p>Send actual anomaly reports via email:</p>
            <a href="?period=1day&action=send" class="button">Send 1-Day Report</a>
            <a href="?period=3days&action=send" class="button">Send 3-Day Report</a>
            <a href="?period=7days&action=send" class="button">Send 7-Day Report</a>
        </div>
        
        <div class="section">
            <h2>🧠 Smart Anomaly Detection</h2>
            <p>Intelligent analysis that adapts to data quality:</p>
            <a href="smart_anomaly_detection.php" class="button" style="background: #059669;">🧠 Run Smart Detection</a>
            <a href="web_data_analysis.php" class="button" style="background: #7c3aed;">📊 Data Quality Analysis</a>
        </div>
        
        <div class="section">
            <h2>👁️ Preview Emails</h2>
            <p>Generate email previews without sending:</p>
            <a href="?period=1day&action=preview" class="button preview">Preview 1-Day</a>
            <a href="?period=3days&action=preview" class="button preview">Preview 3-Day</a>
            <a href="?period=7days&action=preview" class="button preview">Preview 7-Day</a>
        </div>
        
        <div class="section">
            <h2>ℹ️ Information</h2>
            <p><strong>Current Time:</strong> <?php echo date('F j, Y g:i A'); ?></p>
            <p><strong>Email Recipients:</strong> <?php 
                global $config;
                $emails = array_column($config['recipients'], 'email');
                echo implode(', ', $emails);
            ?></p>
            <p><strong>Analysis Logic:</strong> Matches Flutter app exactly (consumption, volume, frequency analysis)</p>
        </div>
    </body>
    </html>
    <?php
}

// Main execution
$period = $_GET['period'] ?? null;
$action = $_GET['action'] ?? null;

if ($period && $action) {
    echo "<html><head><title>GIRScope Anomaly Analysis</title></head><body style='font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px;'>";
    echo "<div style='background: #2563eb; color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 30px;'>";
    echo "<h1>🚨 GIRScope Anomaly Analysis</h1>";
    echo "<p>Running " . strtoupper($period) . " analysis...</p>";
    echo "</div>";
    echo "<div style='background: #f8fafc; padding: 20px; border-radius: 8px; font-family: monospace;'>";
    
    runWebAnomalyAnalysis($period, $action);
    
    echo "</div>";
    echo "<div style='text-align: center; margin-top: 20px;'>";
    echo "<a href='web_anomaly_report.php' style='background: #6b7280; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none;'>← Back to Main Menu</a>";
    echo "</div>";
    echo "</body></html>";
} else {
    generateWebInterface();
}
?>