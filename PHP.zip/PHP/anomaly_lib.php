<?php
/**
 * Shared Anomaly Detection Library
 * Contains all common functions used by different anomaly detection scripts
 */

/**
 * Log messages with timestamp
 */
if (!function_exists('logMessage')) {
    function logMessage($message) {
        echo "[" . date('Y-m-d H:i:s') . "] " . $message . "\n";
    }
}

/**
 * Make HTTP request to Supabase
 */
function makeSupabaseRequest($url, $config, $method = 'GET', $data = null) {
    $headers = [
        'apikey: ' . $config['supabase_key'],
        'Authorization: Bearer ' . $config['supabase_key'],
        'Content-Type: application/json',
        'User-Agent: GIRScope-PHP/1.0'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
    } elseif ($method === 'PATCH') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        throw new Exception("cURL error: $error");
    }
    
    if ($httpCode < 200 || $httpCode >= 300) {
        throw new Exception("Supabase request failed with HTTP code: $httpCode. Response: " . substr($response, 0, 500));
    }
    
    // For PATCH requests, Supabase often returns empty response on success
    if (empty($response) && ($method === 'PATCH' || $method === 'POST')) {
        return true; // Success for empty response on write operations
    }
    
    $decoded = json_decode($response, true);
    if ($decoded === null && json_last_error() !== JSON_ERROR_NONE && !empty($response)) {
        throw new Exception("Invalid JSON response: " . json_last_error_msg());
    }
    
    return $decoded;
}

/**
 * Get fuel transactions for analysis from specified period
 */
function getFuelTransactions($config, $hours) {
    $startDate = date('Y-m-d\TH:i:s', strtotime("-$hours hours"));
    
    $url = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
           'select=*&' .
           'date=gte.' . urlencode($startDate) . '&' .
           'order=date.desc&' .
           'limit=2000';
    
    logMessage("Fetching transactions since: $startDate (last $hours hours)");
    
    $transactions = makeSupabaseRequest($url, $config);
    logMessage("Found " . count($transactions) . " transactions");
    
    // Show sample transactions for debugging
    $sampleCount = min(3, count($transactions));
    for ($i = 0; $i < $sampleCount; $i++) {
        $t = $transactions[$i];
        $date = date('M j, H:i', strtotime($t['date']));
        logMessage("  Sample: {$t['vehicle_name']} | $date | Vol: {$t['volume']}L | Dist: " . ($t['kdelta'] ?? 'N/A') . "km");
    }
    
    return $transactions;
}

/**
 * Get ALL vehicle history for frequency analysis (not limited by date range)
 */
function getAllVehicleHistory($config, $vehicleId) {
    $url = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
           'select=*&' .
           'vehicle_id=eq.' . urlencode($vehicleId) . '&' .
           'order=date.desc&' .
           'limit=1000';
    
    return makeSupabaseRequest($url, $config);
}

/**
 * Get baseline data for anomaly detection - matches Flutter logic
 */
function getBaselineData($config, $vehicleId) {
    $now = new DateTime();
    $baselineEnd = clone $now;
    $baselineEnd->sub(new DateInterval('P7D')); // 7 days ago (end of baseline = start of analysis period)
    $baselineStart = clone $now;
    $baselineStart->sub(new DateInterval('P97D')); // 97 days ago (90-day baseline window)
    
    $baselineStartStr = $baselineStart->format('Y-m-d\TH:i:s');
    $baselineEndStr = $baselineEnd->format('Y-m-d\TH:i:s');
    
    $url = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
           'select=*&' .
           'vehicle_id=eq.' . urlencode($vehicleId) . '&' .
           'date=gte.' . urlencode($baselineStartStr) . '&' .
           'date=lt.' . urlencode($baselineEndStr) . '&' .
           'order=date.desc&' .
           'limit=500';
    
    $baselineTransactions = makeSupabaseRequest($url, $config);
    
    // Fallback if insufficient data
    if (count($baselineTransactions) < 5) {
        $extendedBaselineStart = clone $now;
        $extendedBaselineStart->sub(new DateInterval('P180D')); // 180 days ago
        $extendedBaselineStartStr = $extendedBaselineStart->format('Y-m-d\TH:i:s');
        
        $extendedUrl = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
                      'select=*&' .
                      'vehicle_id=eq.' . urlencode($vehicleId) . '&' .
                      'date=gte.' . urlencode($extendedBaselineStartStr) . '&' .
                      'date=lt.' . urlencode($baselineEndStr) . '&' .
                      'order=date.desc&' .
                      'limit=500';
        
        $baselineTransactions = makeSupabaseRequest($extendedUrl, $config);
        
        // Final fallback
        if (count($baselineTransactions) < 5) {
            $finalUrl = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
                       'select=*&' .
                       'vehicle_id=eq.' . urlencode($vehicleId) . '&' .
                       'date=lt.' . urlencode($baselineEndStr) . '&' .
                       'order=date.desc&' .
                       'limit=500';
            
            $baselineTransactions = makeSupabaseRequest($finalUrl, $config);
        }
    }
    
    return $baselineTransactions;
}

/**
 * Calculate statistical metrics
 */
function calculateStatistics($values) {
    if (empty($values)) {
        return null;
    }
    
    $count = count($values);
    $sum = array_sum($values);
    $mean = $sum / $count;
    
    $variance = 0;
    foreach ($values as $value) {
        $variance += pow($value - $mean, 2);
    }
    $variance = $variance / $count;
    $standardDeviation = sqrt($variance);
    
    return [
        'count' => $count,
        'mean' => $mean,
        'standardDeviation' => $standardDeviation,
        'variance' => $variance,
        'min' => min($values),
        'max' => max($values)
    ];
}

/**
 * Analyze consumption anomaly - matches Flutter logic exactly
 */
function analyzeConsumptionAnomaly($transaction, $baselineTransactions) {
    $standardDeviationThreshold = 2.0;
    $minimumHistoricalSamples = 5;
    
    // Check if transaction has distance data
    if (!isset($transaction['kdelta']) || $transaction['kdelta'] <= 0) {
        return [
            'isAnomaly' => false,
            'reason' => 'No distance data available for consumption calculation',
            'details' => null
        ];
    }
    
    // Calculate consumption for baseline transactions: (Volume / Distance * 100)
    $baselineConsumptions = [];
    foreach ($baselineTransactions as $baselineTransaction) {
        if (isset($baselineTransaction['kdelta']) && $baselineTransaction['kdelta'] > 0) {
            $consumption = ($baselineTransaction['volume'] / $baselineTransaction['kdelta']) * 100;
            $baselineConsumptions[] = $consumption;
        }
    }
    
    if (count($baselineConsumptions) < $minimumHistoricalSamples) {
        return [
            'isAnomaly' => false,
            'reason' => 'Insufficient samples for analysis (' . count($baselineConsumptions) . ' < ' . $minimumHistoricalSamples . ')',
            'details' => null
        ];
    }
    
    $stats = calculateStatistics($baselineConsumptions);
    if (!$stats) {
        return [
            'isAnomaly' => false,
            'reason' => 'Unable to calculate statistics',
            'details' => null
        ];
    }
    
    // Calculate current transaction consumption
    $currentConsumption = ($transaction['volume'] / $transaction['kdelta']) * 100;
    $zScore = ($currentConsumption - $stats['mean']) / $stats['standardDeviation'];
    $isAnomaly = abs($zScore) > $standardDeviationThreshold;
    
    // Determine severity based on z-score
    $severity = 'low';
    $absZScore = abs($zScore);
    if ($absZScore >= 3.0) {
        $severity = 'critical';
    } elseif ($absZScore >= 2.5) {
        $severity = 'high';
    } elseif ($absZScore >= 2.0) {
        $severity = 'medium';
    }
    
    // Generate description
    $expectedConsumption = $stats['mean'];
    $difference = $currentConsumption - $expectedConsumption;
    $percentageDiff = ($difference / $expectedConsumption) * 100;
    
    if ($zScore > 0) {
        $description = sprintf(
            "High fuel consumption: %.1fL/100km vs expected %.1fL/100km (%.1f%% higher than average)",
            $currentConsumption,
            $expectedConsumption,
            abs($percentageDiff)
        );
    } else {
        $description = sprintf(
            "Low fuel consumption: %.1fL/100km vs expected %.1fL/100km (%.1f%% lower than average)",
            $currentConsumption,
            $expectedConsumption,
            abs($percentageDiff)
        );
    }
    
    return [
        'isAnomaly' => $isAnomaly,
        'severity' => $severity,
        'currentConsumption' => $currentConsumption,
        'expectedConsumption' => $stats['mean'],
        'zScore' => $zScore,
        'baselineSamples' => count($baselineConsumptions),
        'description' => $description,
        'details' => $stats
    ];
}

/**
 * Analyze volume anomaly - matches Flutter logic exactly
 */
function analyzeVolumeAnomaly($transaction, $baselineTransactions) {
    $standardDeviationThreshold = 2.0;
    $minimumHistoricalSamples = 5;
    
    // Get volumes from baseline transactions
    $baselineVolumes = [];
    foreach ($baselineTransactions as $baselineTransaction) {
        $baselineVolumes[] = $baselineTransaction['volume'];
    }
    
    if (count($baselineVolumes) < $minimumHistoricalSamples) {
        return [
            'isAnomaly' => false,
            'reason' => 'Insufficient samples for volume analysis (' . count($baselineVolumes) . ' < ' . $minimumHistoricalSamples . ')',
            'details' => null
        ];
    }
    
    $stats = calculateStatistics($baselineVolumes);
    if (!$stats) {
        return [
            'isAnomaly' => false,
            'reason' => 'Unable to calculate volume statistics',
            'details' => null
        ];
    }
    
    // Calculate z-score for current transaction volume
    $currentVolume = $transaction['volume'];
    $zScore = ($currentVolume - $stats['mean']) / $stats['standardDeviation'];
    $isAnomaly = abs($zScore) > $standardDeviationThreshold;
    
    // Determine severity based on z-score
    $severity = 'low';
    $absZScore = abs($zScore);
    if ($absZScore >= 3.0) {
        $severity = 'critical';
    } elseif ($absZScore >= 2.5) {
        $severity = 'high';
    } elseif ($absZScore >= 2.0) {
        $severity = 'medium';
    }
    
    // Generate description
    $expectedVolume = $stats['mean'];
    $difference = $currentVolume - $expectedVolume;
    $percentageDiff = ($difference / $expectedVolume) * 100;
    
    if ($zScore > 0) {
        $description = sprintf(
            "High fuel volume: %.1fL vs expected %.1fL (%.1f%% higher than average)",
            $currentVolume,
            $expectedVolume,
            abs($percentageDiff)
        );
    } else {
        $description = sprintf(
            "Low fuel volume: %.1fL vs expected %.1fL (%.1f%% lower than average)",
            $currentVolume,
            $expectedVolume,
            abs($percentageDiff)
        );
    }
    
    return [
        'isAnomaly' => $isAnomaly,
        'severity' => $severity,
        'type' => 'volume',
        'currentVolume' => $currentVolume,
        'expectedVolume' => $stats['mean'],
        'zScore' => $zScore,
        'baselineSamples' => count($baselineVolumes),
        'description' => $description,
        'details' => $stats
    ];
}

/**
 * Analyze frequency anomaly - matches Flutter logic exactly
 */
function analyzeFrequencyAnomaly($transaction, $baselineTransactions, $allVehicleHistory) {
    $standardDeviationThreshold = 2.0;
    $minimumHistoricalSamples = 2; // Need at least 2 intervals
    
    if (empty($baselineTransactions)) {
        return [
            'isAnomaly' => false,
            'reason' => 'No baseline transactions available for frequency analysis',
            'details' => null
        ];
    }
    
    // Calculate intervals between baseline transactions
    usort($baselineTransactions, function($a, $b) {
        return strtotime($a['date']) - strtotime($b['date']);
    });
    
    $intervals = [];
    for ($i = 1; $i < count($baselineTransactions); $i++) {
        $daysBetween = (strtotime($baselineTransactions[$i]['date']) - strtotime($baselineTransactions[$i-1]['date'])) / (24 * 3600);
        if ($daysBetween > 0) {
            $intervals[] = $daysBetween;
        }
    }
    
    if (count($intervals) < $minimumHistoricalSamples) {
        return [
            'isAnomaly' => false,
            'reason' => 'Insufficient interval data for frequency analysis (' . count($intervals) . ' < ' . $minimumHistoricalSamples . ')',
            'details' => null
        ];
    }
    
    $stats = calculateStatistics($intervals);
    if (!$stats) {
        return [
            'isAnomaly' => false,
            'reason' => 'Unable to calculate frequency statistics',
            'details' => null
        ];
    }
    
    // Find the most recent transaction before current one
    $previousTransactions = [];
    foreach ($allVehicleHistory as $t) {
        if (strtotime($t['date']) < strtotime($transaction['date'])) {
            $previousTransactions[] = $t;
        }
    }
    
    if (empty($previousTransactions)) {
        return [
            'isAnomaly' => false,
            'reason' => 'No previous transactions found for frequency comparison',
            'details' => null
        ];
    }
    
    // Sort by date and get the most recent
    usort($previousTransactions, function($a, $b) {
        return strtotime($b['date']) - strtotime($a['date']);
    });
    
    $daysSinceLastFueling = (strtotime($transaction['date']) - strtotime($previousTransactions[0]['date'])) / (24 * 3600);
    
    // Special handling for same-day refuelings (not considered anomalies)
    if ($daysSinceLastFueling == 0.0) {
        return [
            'isAnomaly' => false,
            'reason' => 'Same-day refueling - not considered an anomaly',
            'details' => null
        ];
    }
    
    // Calculate z-score
    $zScore = ($daysSinceLastFueling - $stats['mean']) / $stats['standardDeviation'];
    $isAnomaly = abs($zScore) > $standardDeviationThreshold;
    
    // Determine severity based on z-score
    $severity = 'low';
    $absZScore = abs($zScore);
    if ($absZScore >= 3.0) {
        $severity = 'critical';
    } elseif ($absZScore >= 2.5) {
        $severity = 'high';
    } elseif ($absZScore >= 2.0) {
        $severity = 'medium';
    }
    
    // Generate description
    $expectedFrequency = $stats['mean'];
    
    if ($zScore > 0) {
        $description = sprintf(
            "Infrequent refueling: %.1f days since last fueling vs expected %.1f days",
            $daysSinceLastFueling,
            $expectedFrequency
        );
    } else {
        $description = sprintf(
            "Frequent refueling: %.1f days since last fueling vs expected %.1f days",
            $daysSinceLastFueling,
            $expectedFrequency
        );
    }
    
    return [
        'isAnomaly' => $isAnomaly,
        'severity' => $severity,
        'type' => 'frequency',
        'daysSinceLastFueling' => $daysSinceLastFueling,
        'expectedFrequency' => $stats['mean'],
        'zScore' => $zScore,
        'baselineSamples' => count($intervals),
        'description' => $description,
        'details' => $stats
    ];
}

/**
 * Analyze flag-based anomalies - matches Flutter logic exactly
 */
function analyzeFlagAnomalies($transaction) {
    $flagAnomalies = [];
    
    // Check manual flag
    if (isset($transaction['manual']) && $transaction['manual']) {
        $flagAnomalies[] = [
            'isAnomaly' => true,
            'type' => 'manual',
            'severity' => 'medium',
            'description' => 'Manual fueling detected'
        ];
    }
    
    // Check forced meter flag
    if (isset($transaction['mtr_forced']) && $transaction['mtr_forced']) {
        $flagAnomalies[] = [
            'isAnomaly' => true,
            'type' => 'forced_meter',
            'severity' => 'high',
            'description' => 'Forced meter reading detected'
        ];
    }
    
    // Check maximum volume flag
    if (isset($transaction['vol_max']) && $transaction['vol_max']) {
        $flagAnomalies[] = [
            'isAnomaly' => true,
            'type' => 'max_volume',
            'severity' => 'low',
            'description' => 'Maximum volume reached'
        ];
    }
    
    // Check meter reset flags
    if ((isset($transaction['new_kmeter']) && $transaction['new_kmeter']) || 
        (isset($transaction['new_hmeter']) && $transaction['new_hmeter'])) {
        $flagAnomalies[] = [
            'isAnomaly' => true,
            'type' => 'meter_reset',
            'severity' => 'medium',
            'description' => 'Meter reset detected'
        ];
    }
    
    // Check high consumption based on kcons/hcons values
    $consumptionThreshold = 50.0; // Default threshold
    if ((isset($transaction['kcons']) && $transaction['kcons'] > $consumptionThreshold) ||
        (isset($transaction['hcons']) && $transaction['hcons'] > $consumptionThreshold)) {
        $actualConsumption = $transaction['kcons'] ?? $transaction['hcons'];
        $flagAnomalies[] = [
            'isAnomaly' => true,
            'type' => 'high_consumption',
            'severity' => 'high',
            'description' => sprintf('High consumption detected: %.1fL/100km', $actualConsumption)
        ];
    }
    
    return $flagAnomalies;
}

/**
 * Detect anomalies in transactions - matches Flutter logic exactly
 * Returns array with 'anomalies' and 'vehicleAnalysis' keys
 */
function detectAnomalies($transactions, $config) {
    $anomalies = [];
    $processedVehicles = [];
    $vehicleAnalysis = [];
    
    // Group transactions by vehicle to get comprehensive analysis
    $vehicleTransactions = [];
    foreach ($transactions as $transaction) {
        $vehicleId = $transaction['vehicle_id'];
        if (!empty($vehicleId)) {
            if (!isset($vehicleTransactions[$vehicleId])) {
                $vehicleTransactions[$vehicleId] = [];
            }
            $vehicleTransactions[$vehicleId][] = $transaction;
        }
    }
    
    foreach ($vehicleTransactions as $vehicleId => $vehicleTxns) {
        $vehicleName = $vehicleTxns[0]['vehicle_name'];
        $transactionCount = count($vehicleTxns);
        
        // Get baseline data for this vehicle
        $baselineData = getBaselineData($config, $vehicleId);
        $baselineCount = count($baselineData);
        logMessage("🔍 Vehicle: $vehicleName - Found $baselineCount baseline transactions");
        
        // Initialize analysis tracking
        $vehicleHasAnomalies = false;
        $consumptionCheck = 'not_checked';
        $volumeCheck = 'not_checked';
        $frequencyCheck = 'not_checked';
        
        // Analyze each transaction for this vehicle
        foreach ($vehicleTxns as $transaction) {
            $detectedAnomalies = [];
            
            // 0. Flag-based anomaly detection (matches Flutter logic exactly)
            $flagAnomalies = analyzeFlagAnomalies($transaction);
            if (!empty($flagAnomalies)) {
                $detectedAnomalies = array_merge($detectedAnomalies, $flagAnomalies);
                $vehicleHasAnomalies = true;
                foreach ($flagAnomalies as $flagAnomaly) {
                    logMessage("🚨 Flag anomaly: Vehicle $vehicleName - " . $flagAnomaly['description']);
                }
            }
            
            // 1. Consumption analysis (only if kdelta is available)
            if (!empty($transaction['kdelta']) && $transaction['kdelta'] > 0) {
                $consumptionResult = analyzeConsumptionAnomaly($transaction, $baselineData);
                $consumptionCheck = $consumptionResult['isAnomaly'] ? 'anomaly_found' : 'checked';
                if ($consumptionResult['isAnomaly']) {
                    $detectedAnomalies[] = $consumptionResult;
                    $vehicleHasAnomalies = true;
                    logMessage("🚨 Consumption anomaly: Vehicle $vehicleName - " . $consumptionResult['description']);
                }
            } else {
                $consumptionCheck = 'no_distance';
            }
            
            // 2. Volume analysis (always runs if sufficient baseline data)
            if ($baselineCount >= 5) {
                $volumeResult = analyzeVolumeAnomaly($transaction, $baselineData);
                $volumeCheck = $volumeResult['isAnomaly'] ? 'anomaly_found' : 'checked';
                if ($volumeResult['isAnomaly']) {
                    $detectedAnomalies[] = $volumeResult;
                    $vehicleHasAnomalies = true;
                    logMessage("🚨 Volume anomaly: Vehicle $vehicleName - " . $volumeResult['description']);
                }
            } else {
                $volumeCheck = 'insufficient_data';
            }
            
            // 3. Frequency analysis (always runs if sufficient baseline data)
            if ($baselineCount >= 2) {
                $allVehicleHistory = getAllVehicleHistory($config, $vehicleId);
                $frequencyResult = analyzeFrequencyAnomaly($transaction, $baselineData, $allVehicleHistory);
                $frequencyCheck = $frequencyResult['isAnomaly'] ? 'anomaly_found' : 'checked';
                if ($frequencyResult['isAnomaly']) {
                    $detectedAnomalies[] = $frequencyResult;
                    $vehicleHasAnomalies = true;
                    logMessage("🚨 Frequency anomaly: Vehicle $vehicleName - " . $frequencyResult['description']);
                }
            } else {
                $frequencyCheck = 'insufficient_data';
            }
            
            // If any anomalies were detected, add this transaction to the anomalies list
            if (!empty($detectedAnomalies)) {
                $transaction['anomaly_analysis'] = $detectedAnomalies;
                $anomalies[] = $transaction;
                logMessage("🚨 Total anomalies for Vehicle $vehicleName: " . count($detectedAnomalies));
            }
        }
        
        // Store vehicle analysis summary
        $vehicleAnalysis[] = [
            'name' => $vehicleName,
            'vehicle_id' => $vehicleId,
            'transaction_count' => $transactionCount,
            'baseline_count' => $baselineCount,
            'consumption_check' => $consumptionCheck,
            'volume_check' => $volumeCheck,
            'frequency_check' => $frequencyCheck,
            'has_anomalies' => $vehicleHasAnomalies
        ];
    }
    
    return [
        'anomalies' => $anomalies,
        'vehicleAnalysis' => $vehicleAnalysis
    ];
}

/**
 * Update anomaly flags in Supabase
 */
function updateAnomalyFlagsInSupabase($anomalies, $config) {
    if (empty($anomalies)) {
        return 0;
    }
    
    logMessage("Updating anomaly flags in Supabase...");
    
    $updatedCount = 0;
    foreach ($anomalies as $anomaly) {
        try {
            // Debug: log the anomaly structure
            logMessage("Debug: Anomaly keys: " . implode(', ', array_keys($anomaly)));
            
            $transactionId = $anomaly['id'] ?? null;
            if (!$transactionId) {
                logMessage("Warning: No transaction ID found in anomaly data");
                continue;
            }
            
            $updateUrl = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
                        'id=eq.' . urlencode($transactionId);
            
            // Convert all detected anomalies to the format expected by Supabase
            $anomalyData = [];
            $detectedAnomalies = $anomaly['anomaly_analysis'];
            
            // Handle both single anomaly and array of anomalies
            if (!is_array($detectedAnomalies) || !isset($detectedAnomalies[0])) {
                // Single anomaly format (legacy)
                $anomalyData[] = [
                    'type' => ucfirst($detectedAnomalies['type'] ?? 'consumption') . ' Anomaly',
                    'severity' => $detectedAnomalies['severity'] ?? 'medium',
                    'description' => $detectedAnomalies['description'] ?? 'Anomaly detected'
                ];
            } else {
                // Multiple anomalies format
                foreach ($detectedAnomalies as $singleAnomaly) {
                    $anomalyData[] = [
                        'type' => ucfirst($singleAnomaly['type'] ?? 'consumption') . ' Anomaly',
                        'severity' => $singleAnomaly['severity'] ?? 'medium',
                        'description' => $singleAnomaly['description'] ?? 'Anomaly detected'
                    ];
                }
            }
            
            $updateData = [
                'has_anomalies' => true,
                'anomalies_json' => json_encode($anomalyData)
            ];
            
            makeSupabaseRequest($updateUrl, $config, 'PATCH', $updateData);
            $updatedCount++;
        } catch (Exception $e) {
            logMessage("Failed to update transaction {$anomaly['id']}: " . $e->getMessage());
        }
    }
    
    logMessage("✅ Updated $updatedCount transactions with anomaly flags");
    return $updatedCount;
}

/**
 * Generate email body for anomaly report
 */
function generateEmailBody($anomalies, $periodLabel, $hours, $allAnalyzedVehicles = null) {
    $totalAnomalies = count($anomalies);
    
    // Set timezone to Pacific/Efate (GMT+11)
    $timezone = new DateTimeZone('Pacific/Efate');
    $now = new DateTime('now', $timezone);
    $reportDate = $now->format('F j, Y');
    $reportTime = $now->format('g:i A');
    
    // Convert hours to days for display
    $analysisDays = $hours / 24;
    
    $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>GIRScope ' . htmlspecialchars($periodLabel) . ' Anomaly Report</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 20px; }
        .header { background: #2563eb; color: white; padding: 20px; text-align: center; border-radius: 8px; }
        .summary { background: #f8fafc; padding: 15px; margin: 20px 0; border-radius: 8px; }
        .vehicle-analysis { background: #f0fdf4; padding: 15px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #059669; }
        .analysis-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .analysis-table th, .analysis-table td { padding: 8px; text-align: left; border-bottom: 1px solid #e2e8f0; font-size: 12px; }
        .analysis-table th { background: #f8fafc; font-weight: bold; }
        .status-ok { color: #059669; font-weight: bold; }
        .status-anomaly { color: #dc2626; font-weight: bold; }
        .status-limited { color: #ea580c; font-weight: bold; }
        .status-insufficient { color: #6b7280; font-style: italic; }
        .anomaly { border: 1px solid #e2e8f0; margin: 10px 0; padding: 15px; border-radius: 8px; }
        .high { border-left: 4px solid #dc2626; }
        .medium { border-left: 4px solid #ea580c; }
        .low { border-left: 4px solid #eab308; }
        .footer { text-align: center; color: #666; font-size: 12px; margin-top: 30px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>GIRScope ' . htmlspecialchars($periodLabel) . ' Anomaly Report</h1>
        <p>Report Date: ' . htmlspecialchars($reportDate) . ' at ' . htmlspecialchars($reportTime) . '</p>
        <p>Analysis Period: ' . $analysisDays . ' days</p>
    </div>
    
    <div class="summary">
        <h2>Executive Summary</h2>
        <p><strong>Total Anomalies Found:</strong> ' . $totalAnomalies . '</p>';
    
    // Add vehicle analysis summary if provided
    if ($allAnalyzedVehicles) {
        $totalVehicles = count($allAnalyzedVehicles);
        $vehiclesWithAnomalies = 0;
        foreach ($allAnalyzedVehicles as $vehicle) {
            if ($vehicle['has_anomalies']) {
                $vehiclesWithAnomalies++;
            }
        }
        $vehiclesNormal = $totalVehicles - $vehiclesWithAnomalies;
        
        $html .= '
        <p><strong>Vehicles Analyzed:</strong> ' . $totalVehicles . '</p>
        <p><strong>Vehicles with Issues:</strong> ' . $vehiclesWithAnomalies . '</p>
        <p><strong>Vehicles Normal:</strong> ' . $vehiclesNormal . '</p>';
    }
    
    $html .= '</div>';
    
    // Add detailed vehicle analysis table if provided
    if ($allAnalyzedVehicles) {
        $html .= '
    <div class="vehicle-analysis">
        <h2>Vehicle Analysis Details</h2>
        <p>This table shows all vehicles that had transactions in the analysis period and what checks were performed:</p>
        <table class="analysis-table">
            <tr>
                <th>Vehicle</th>
                <th>Transactions</th>
                <th>Baseline Data</th>
                <th>Consumption Check</th>
                <th>Volume Check</th>
                <th>Frequency Check</th>
                <th>Status</th>
            </tr>';
        
        foreach ($allAnalyzedVehicles as $vehicleData) {
            $vehicleName = htmlspecialchars($vehicleData['name']);
            // Clean up problematic characters in vehicle names for email display
            $vehicleName = str_replace(['n°', 'nº', 'n˚', 'Â°', '°'], ['n', 'n', 'n', '', ''], $vehicleName);
            
            $transactionCount = $vehicleData['transaction_count'];
            $baselineCount = $vehicleData['baseline_count'];
            $consumptionCheck = $vehicleData['consumption_check'];
            $volumeCheck = $vehicleData['volume_check'];
            $frequencyCheck = $vehicleData['frequency_check'];
            $hasAnomalies = $vehicleData['has_anomalies'];
            
            // Determine overall status
            if ($hasAnomalies) {
                $status = '<span class="status-anomaly">ANOMALIES FOUND</span>';
            } elseif ($consumptionCheck === 'checked' && $volumeCheck === 'checked' && $frequencyCheck === 'checked') {
                $status = '<span class="status-ok">ALL CHECKS PASSED</span>';
            } elseif ($baselineCount < 5) {
                $status = '<span class="status-insufficient">INSUFFICIENT DATA</span>';
            } else {
                $status = '<span class="status-limited">LIMITED CHECKS</span>';
            }
            
            // Format check results
            $consumptionResult = $consumptionCheck === 'checked' ? 'PASSED' : 
                               ($consumptionCheck === 'no_distance' ? 'NO DISTANCE DATA' : 'INSUFFICIENT DATA');
            $volumeResult = $volumeCheck === 'checked' ? 'PASSED' : 'INSUFFICIENT DATA';
            $frequencyResult = $frequencyCheck === 'checked' ? 'PASSED' : 'INSUFFICIENT DATA';
            
            $html .= '
            <tr>
                <td><strong>' . $vehicleName . '</strong></td>
                <td>' . $transactionCount . '</td>
                <td>' . $baselineCount . '</td>
                <td>' . $consumptionResult . '</td>
                <td>' . $volumeResult . '</td>
                <td>' . $frequencyResult . '</td>
                <td>' . $status . '</td>
            </tr>';
        }
        
        $html .= '
        </table>
        <p style="font-size: 11px; color: #6b7280; margin-top: 10px;">
            <strong>Legend:</strong> 
            PASSED = Check performed and passed | 
            NO DISTANCE DATA = Check skipped due to missing data | 
            INSUFFICIENT DATA = Check not possible due to insufficient historical data
        </p>
    </div>';
    }
    
    // Anomalies section
    if (empty($anomalies)) {
        $html .= '<div style="text-align: center; padding: 40px; color: #059669;">
            <h2>No Anomalies Detected</h2>
            <p>All fuel transactions appear normal for the ' . strtolower($periodLabel) . ' period.</p>
        </div>';
    } else {
        $html .= '<div style="margin: 20px 0;">
            <h2>Detected Anomalies</h2>';
        
        foreach ($anomalies as $anomaly) {
            $date = date('M j, Y g:i A', strtotime($anomaly['date']));
            $vehicleName = htmlspecialchars($anomaly['vehicle_name'] ?? 'Unknown Vehicle');
            // Clean up problematic characters in vehicle names for email display
            $vehicleName = str_replace(['n°', 'nº', 'n˚', 'Â°', '°'], ['n', 'n', 'n', '', ''], $vehicleName);
            
            $driverName = htmlspecialchars($anomaly['driver_name'] ?? 'Unknown Driver');
            $siteName = htmlspecialchars($anomaly['site_name'] ?? 'Unknown Site');
            $volume = number_format($anomaly['volume'], 1);
            
            $detectedAnomalies = $anomaly['anomaly_analysis'];
            if (!is_array($detectedAnomalies) || !isset($detectedAnomalies[0])) {
                $detectedAnomalies = [$detectedAnomalies];
            }
            
            $severity = $detectedAnomalies[0]['severity'] ?? 'medium';
            $description = htmlspecialchars($detectedAnomalies[0]['description'] ?? 'Anomaly detected');
            
            $html .= '<div class="anomaly ' . $severity . '">
                <h3>' . $vehicleName . ' - ' . ucfirst($severity) . ' Severity</h3>
                <p><strong>Date:</strong> ' . $date . '</p>
                <p><strong>Driver:</strong> ' . $driverName . '</p>
                <p><strong>Location:</strong> ' . $siteName . '</p>
                <p><strong>Volume:</strong> ' . $volume . ' L</p>
                <p><strong>Issue:</strong> ' . $description . '</p>
            </div>';
        }
        
        $html .= '</div>';
    }
    
    $html .= '<div class="footer">
        <p>This report was automatically generated by GIRScope Anomaly Detection System</p>
        <p>Developed by IEC (Vanuatu) - <a href="https://iec.vu">www.iec.vu</a></p>
    </div>
</body>
</html>';
    
    return $html;
}

/**
 * Legacy email generation function (kept for compatibility)
 */
function generateLegacyEmailBody($anomalies, $periodLabel, $hours) {
    $totalAnomalies = count($anomalies);
    $reportDate = date('F j, Y');
    $reportTime = date('g:i A');
    
    // Count anomalies by severity and type
    $severityCounts = [];
    $typeCounts = [];
    foreach ($anomalies as $anomaly) {
        $detectedAnomalies = $anomaly['anomaly_analysis'];
        
        // Handle both single anomaly and array of anomalies
        if (!is_array($detectedAnomalies) || !isset($detectedAnomalies[0])) {
            // Single anomaly format (legacy)
            $severity = $detectedAnomalies['severity'] ?? 'medium';
            $type = $detectedAnomalies['type'] ?? 'consumption';
            $severityCounts[$severity] = ($severityCounts[$severity] ?? 0) + 1;
            $typeCounts[$type] = ($typeCounts[$type] ?? 0) + 1;
        } else {
            // Multiple anomalies format
            foreach ($detectedAnomalies as $singleAnomaly) {
                $severity = $singleAnomaly['severity'] ?? 'medium';
                $type = $singleAnomaly['type'] ?? 'consumption';
                $severityCounts[$severity] = ($severityCounts[$severity] ?? 0) + 1;
                $typeCounts[$type] = ($typeCounts[$type] ?? 0) + 1;
            }
        }
    }
    
    $html = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>GIRScope ' . $periodLabel . ' Anomaly Report</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
            .summary { background: #f8fafc; padding: 15px; margin: 20px 0; border-radius: 8px; }
            .anomaly-card { border: 1px solid #e2e8f0; margin: 10px 0; padding: 15px; border-radius: 8px; }
            .severity-high { border-left: 4px solid #dc2626; }
            .severity-medium { border-left: 4px solid #ea580c; }
            .severity-low { border-left: 4px solid #eab308; }
            .severity-critical { border-left: 4px solid #7c2d12; background: #fef2f2; }
            .vehicle-info { background: #f1f5f9; padding: 10px; border-radius: 4px; margin: 10px 0; }
            .anomaly-details { background: #fff7ed; padding: 10px; border-radius: 4px; margin: 5px 0; }
            .footer { text-align: center; color: #64748b; font-size: 12px; margin-top: 30px; }
            table { width: 100%; border-collapse: collapse; margin: 10px 0; }
            th, td { padding: 8px; text-align: left; border-bottom: 1px solid #e2e8f0; }
            th { background: #f8fafc; font-weight: bold; }
            .stats-summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin: 15px 0; }
            .stat-card { background: white; padding: 12px; border-radius: 6px; border: 1px solid #e2e8f0; text-align: center; }
            .alert-icon { color: #dc2626; font-weight: bold; }
            .chart-icon { color: #2563eb; font-weight: bold; }
            .search-icon { color: #059669; font-weight: bold; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>GIRScope ' . $periodLabel . ' Anomaly Report</h1>
            <p>Report Date: ' . $reportDate . ' at ' . $reportTime . '</p>
            <p>Analysis Period: ' . $periodLabel . ' (' . $hours . ' hours)</p>
        </div>
        
        <div class="summary">
            <h2>Summary</h2>
            <div class="stats-summary">
                <div class="stat-card">
                    <strong>' . $totalAnomalies . '</strong><br>
                    <small>Total Anomalies</small>
                </div>';
    
    if (!empty($severityCounts)) {
        foreach ($severityCounts as $severity => $count) {
            $severityLabel = ucfirst($severity);
            $html .= '
                <div class="stat-card">
                    <strong>' . $count . '</strong><br>
                    <small>' . $severityLabel . ' Severity</small>
                </div>';
        }
    }
    
    $html .= '
            </div>
        </div>';
    
    if (empty($anomalies)) {
        $html .= '
        <div style="text-align: center; padding: 40px; color: #10b981;">
            <h2>✅ No Anomalies Detected</h2>
            <p>Great news! No fuel consumption anomalies were detected in the ' . strtolower($periodLabel) . '.</p>
        </div>';
    } else {
        $html .= '<h2>🔍 Detailed Anomaly Report</h2>';
        
        foreach ($anomalies as $anomaly) {
            $date = date('M j, Y g:i A', strtotime($anomaly['date']));
            $vehicleName = $anomaly['vehicle_name'] ?? 'Unknown Vehicle';
            $driverName = $anomaly['driver_name'] ?? 'Unknown Driver';
            $siteName = $anomaly['site_name'] ?? 'Unknown Site';
            $volume = number_format($anomaly['volume'], 1);
            
            $analysis = $anomaly['anomaly_analysis'] ?? [];
            $severity = $analysis['severity'] ?? 'medium';
            $currentConsumption = $analysis['currentConsumption'] ?? 0;
            $expectedConsumption = $analysis['expectedConsumption'] ?? 0;
            $zScore = $analysis['zScore'] ?? 0;
            $description = $analysis['description'] ?? 'Fuel consumption anomaly detected';
            
            $severityLabel = ucfirst($severity);
            
            $html .= '
            <div class="anomaly-card severity-' . $severity . '">
                <h3>🚗 ' . htmlspecialchars($vehicleName) . ' - ' . $severityLabel . ' Severity</h3>
                
                <div class="vehicle-info">
                    <table>
                        <tr><th>Date & Time:</th><td>' . $date . '</td></tr>
                        <tr><th>Driver:</th><td>' . htmlspecialchars($driverName) . '</td></tr>
                        <tr><th>Location:</th><td>' . htmlspecialchars($siteName) . '</td></tr>
                        <tr><th>Fuel Volume:</th><td>' . $volume . ' L</td></tr>
                        <tr><th>Distance:</th><td>' . number_format($anomaly['kdelta'] ?? 0, 1) . ' km</td></tr>
                        <tr><th>Transaction ID:</th><td>' . htmlspecialchars($anomaly['id']) . '</td></tr>
                    </table>
                </div>
                
                <div class="anomaly-details">
                    <h4>⚠️ Anomaly Analysis</h4>
                    <p><strong>' . $severityLabel . ' - Fuel Consumption Anomaly</strong></p>
                    <p>' . htmlspecialchars($description) . '</p>
                    <table>
                        <tr><th>Current Consumption:</th><td>' . number_format($currentConsumption, 1) . ' L/100km</td></tr>
                        <tr><th>Expected Consumption:</th><td>' . number_format($expectedConsumption, 1) . ' L/100km</td></tr>
                        <tr><th>Z-Score:</th><td>' . number_format($zScore, 2) . '</td></tr>
                        <tr><th>Baseline Samples:</th><td>' . ($analysis['baselineSamples'] ?? 0) . ' transactions</td></tr>
                    </table>
                </div>
            </div>';
        }
    }
    
    $html .= '
        <div class="footer">
            <p>This report was automatically generated by GIRScope Anomaly Detection System</p>
            <p>Analysis uses the same algorithms as the mobile app with historical baseline comparison</p>
            <p>Developed by IEC (IT Engineers Company) - <a href="https://iec.vu">www.iec.vu</a></p>
        </div>
    </body>
    </html>';
    
    return $html;
}

/**
 * Send email using PHPMailer
 */
function sendEmail($to, $name, $subject, $body, $config) {
    logMessage("📧 sendEmail() called for: $to");
    
    try {
        require_once('/var/www/pascal/PHPMailer.php');
        require_once('/var/www/pascal/SMTP.php');
        logMessage("📧 PHPMailer files loaded successfully");
    } catch (Exception $e) {
        logMessage("❌ Failed to load PHPMailer: " . $e->getMessage());
        return false;
    }
    
    $smtpUser = getenv('SMTP_USER');
    $smtpPassword = getenv('SMTP_PASSWORD');
    
    // Debug logging
    logMessage("SMTP Debug - User: " . ($smtpUser ? 'SET' : 'NOT SET'));
    logMessage("SMTP Debug - Password: " . ($smtpPassword ? 'SET' : 'NOT SET'));
    logMessage("SMTP Debug - Host: " . $config['smtp_host']);
    logMessage("SMTP Debug - Port: " . $config['smtp_port']);
    
    if (!$smtpUser || !$smtpPassword) {
        logMessage("❌ SMTP credentials not configured - cannot send email");
        return false;
    }
    
    $mail = new PHPMailer\PHPMailer\PHPMailer(false);
    
    $mail->isSMTP();
    $mail->Host = $config['smtp_host'];
    $mail->Port = $config['smtp_port'];
    $mail->SMTPSecure = $config['smtp_secure'];
    $mail->SMTPAuth = true;
    $mail->Username = $smtpUser;
    $mail->Password = $smtpPassword;
    
    $mail->setFrom($config['default_from'], $config['sender_name']);
    $mail->addAddress($to, $name);
    $mail->Subject = $subject;
    $mail->isHTML(true);
    $mail->Body = $body;
    
    if ($mail->send()) {
        return true;
    } else {
        logMessage("Email failed to $to: " . $mail->ErrorInfo);
        return false;
    }
}

/**
 * Sync latest data from W150 API to Supabase
 */
function syncFromW150API($config) {
    try {
        logMessage("🔄 Starting W150 API sync...");
        
        // Klervi API endpoint and authentication
        $w150ApiUrl = $config['w150_api_url'] ?? null;
        $w150ApiKey = $config['w150_api_key'] ?? null;
        
        if (!$w150ApiUrl || !$w150ApiKey) {
            return [
                'success' => false,
                'message' => 'W150 API URL or API key not configured in anomaly_config.php'
            ];
        }
        
        // Get the last synced ID from Supabase to resume sync (exactly like Dart)
        $lastId = null;
        try {
            $lastTxUrl = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
                        'select=id&order=date.desc&limit=1';
            $lastTxResponse = makeSupabaseRequest($lastTxUrl, $config);
            
            if (!empty($lastTxResponse) && isset($lastTxResponse[0]['id'])) {
                $lastId = $lastTxResponse[0]['id'];
                logMessage("Resuming sync from lastId: $lastId");
            }
        } catch (Exception $e) {
            logMessage("Error getting last synced ID from Supabase: " . $e->getMessage());
            // Continue without lastId if there's an error, will fetch all
        }
        
        // Build URL with lastId parameter (exactly like Dart)
        $queryParams = [];
        if ($lastId) {
            $queryParams['last_id'] = $lastId;
        }
        $w150UrlWithParams = $w150ApiUrl;
        if (!empty($queryParams)) {
            $w150UrlWithParams .= '?' . http_build_query($queryParams);
        }
        
        logMessage("Attempting to connect to Klervi API: $w150UrlWithParams");
        
        // Make request to Klervi API with pagination
        $headers = [
            'X-Klervi-API-Key: ' . $w150ApiKey,
            'Content-Type: application/json'
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $w150UrlWithParams);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        $w150Response = curl_exec($ch);
        $w150HttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $w150Error = curl_error($ch);
        curl_close($ch);
        
        if ($w150Error) {
            return [
                'success' => false,
                'message' => "W150 API connection error: $w150Error"
            ];
        }
        
        if ($w150HttpCode !== 200) {
            return [
                'success' => false,
                'message' => "W150 API returned HTTP $w150HttpCode"
            ];
        }
        
        $w150Data = json_decode($w150Response, true);
        if (!$w150Data) {
            return [
                'success' => false,
                'message' => "Invalid JSON response from Klervi API"
            ];
        }
        
        // Handle different response formats (exactly like Dart implementation)
        $w150Transactions = [];
        $moreData = false;
        
        if (is_array($w150Data) && isset($w150Data['result'])) {
            $w150Transactions = $w150Data['result'];
            $moreData = $w150Data['more'] ?? false;
        } elseif (is_array($w150Data) && isset($w150Data['data'])) {
            $w150Transactions = $w150Data['data'];
            $moreData = $w150Data['more'] ?? false;
        } elseif (is_array($w150Data) && isset($w150Data['transactions'])) {
            $w150Transactions = $w150Data['transactions'];
            $moreData = $w150Data['more'] ?? false;
        } elseif (is_array($w150Data) && isset($w150Data['results'])) {
            $w150Transactions = $w150Data['results'];
            $moreData = $w150Data['more'] ?? false;
        } elseif (is_array($w150Data)) {
            $w150Transactions = $w150Data;
            $moreData = false; // If it's a direct array, assume no pagination
        }
        
        logMessage("Retrieved " . count($w150Transactions) . " transactions from Klervi API. More: " . ($moreData ? 'true' : 'false'));
        
        if (empty($w150Transactions)) {
            return [
                'success' => true,
                'message' => "No new transactions from Klervi API"
            ];
        }
        
        // Sync transactions to Supabase (exactly like Dart implementation)
        $totalSynced = 0;
        $syncedCount = 0;
        $updatedCount = 0;
        $errorCount = 0;
        
        // Process current batch
        foreach ($w150Transactions as $transaction) {
            try {
                // Convert Klervi API format to Supabase format (based on actual API structure)
                $supabaseTransaction = [
                    'id' => $transaction['id'] ?? '',
                    'transac_id' => $transaction['transac_id'] ?? '0',
                    'date' => isset($transaction['date']) ? date('c', strtotime($transaction['date'])) : date('c'),
                    'vehicle_name' => isset($transaction['vehicle']['name']) ? $transaction['vehicle']['name'] : '',
                    'vehicle_id' => isset($transaction['vehicle']['id']) ? $transaction['vehicle']['id'] : null,
                    'driver_name' => isset($transaction['driver']['name']) ? $transaction['driver']['name'] : '',
                    'driver_id' => isset($transaction['driver']['id']) ? $transaction['driver']['id'] : null,
                    'site_name' => isset($transaction['site']['name']) ? $transaction['site']['name'] : '',
                    'site_id' => isset($transaction['site']['id']) ? $transaction['site']['id'] : null,
                    'volume' => isset($transaction['volume']) ? (float)$transaction['volume'] : 0.0,
                    'kdelta' => isset($transaction['kdelta']) ? (float)$transaction['kdelta'] : null,
                    'kcons' => isset($transaction['kcons']) ? (float)$transaction['kcons'] : null,
                    'hcons' => isset($transaction['hcons']) ? (float)$transaction['hcons'] : null,
                    'manual' => isset($transaction['manual']) ? (bool)$transaction['manual'] : false,
                    'mtr_forced' => isset($transaction['mtr_forced']) ? (bool)$transaction['mtr_forced'] : false,
                    'vol_max' => isset($transaction['vol_max']) ? (bool)$transaction['vol_max'] : false,
                    'new_kmeter' => isset($transaction['new_kmeter']) ? (bool)$transaction['new_kmeter'] : false,
                    'new_hmeter' => isset($transaction['new_hmeter']) ? (bool)$transaction['new_hmeter'] : false,
                ];
                
                // Skip transactions without required fields
                if (empty($supabaseTransaction['id'])) {
                    logMessage("Skipping transaction with missing ID");
                    continue;
                }
                
                // Check if transaction already exists in Supabase
                $checkUrl = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
                           'id=eq.' . urlencode($supabaseTransaction['id']);
                
                $existingTx = makeSupabaseRequest($checkUrl, $config);
                
                if (empty($existingTx)) {
                    // Insert new transaction
                    $insertUrl = $config['supabase_url'] . '/rest/v1/fuel_transactions';
                    makeSupabaseRequest($insertUrl, $config, 'POST', $supabaseTransaction);
                    $syncedCount++;
                    logMessage("Inserted new transaction: {$supabaseTransaction['id']}");
                } else {
                    // Update existing transaction (only if needed)
                    $updateUrl = $config['supabase_url'] . '/rest/v1/fuel_transactions?' . 
                                'id=eq.' . urlencode($supabaseTransaction['id']);
                    makeSupabaseRequest($updateUrl, $config, 'PATCH', $supabaseTransaction);
                    $updatedCount++;
                    logMessage("Updated existing transaction: {$supabaseTransaction['id']}");
                }
            } catch (Exception $e) {
                $errorCount++;
                $transactionId = $transaction['id'] ?? 'unknown';
                logMessage("Error syncing transaction $transactionId: " . $e->getMessage());
            }
        }
        
        $totalProcessed = $syncedCount + $updatedCount;
        $message = "Processed $totalProcessed transactions (new: $syncedCount, updated: $updatedCount";
        if ($errorCount > 0) {
            $message .= ", errors: $errorCount";
        }
        $message .= ")";
        
        return [
            'success' => true,
            'message' => $message,
            'synced' => $syncedCount,
            'updated' => $updatedCount,
            'errors' => $errorCount
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => "W150 sync failed: " . $e->getMessage()
        ];
    }
}

/**
 * Send emails to all recipients
 */
function sendAnomalyEmails($anomalies, $periodLabel, $hours, $config, $vehicleAnalysis = null) {
    logMessage("📧 Generating email body...");
    $emailBody = generateEmailBody($anomalies, $periodLabel, $hours, $vehicleAnalysis);
    
    $subject = "GIRScope $periodLabel Anomaly Report - " . date('M j, Y') . 
              (count($anomalies) > 0 ? " (" . count($anomalies) . " anomalies)" : " (No anomalies)");
    
    logMessage("📧 Email subject: $subject");
    logMessage("📧 Email body length: " . strlen($emailBody) . " characters");
    
    $successCount = 0;
    $failCount = 0;
    
    logMessage("📧 Starting to send to " . count($config['recipients']) . " recipients...");
    
    foreach ($config['recipients'] as $i => $recipient) {
        logMessage("📧 [" . ($i + 1) . "/" . count($config['recipients']) . "] Attempting to send to: " . $recipient['email']);
        
        try {
            if (sendEmail($recipient['email'], $recipient['name'], $subject, $emailBody, $config)) {
                $successCount++;
                logMessage("✅ [" . ($i + 1) . "] Email sent successfully to: " . $recipient['email']);
            } else {
                $failCount++;
                logMessage("❌ [" . ($i + 1) . "] Failed to send email to: " . $recipient['email']);
            }
        } catch (Exception $e) {
            $failCount++;
            logMessage("❌ [" . ($i + 1) . "] Exception sending email to " . $recipient['email'] . ": " . $e->getMessage());
        }
    }
    
    logMessage("Email sending completed. Success: $successCount, Failed: $failCount");
    return $successCount;
}
?>